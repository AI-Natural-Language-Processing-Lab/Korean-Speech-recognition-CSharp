﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Speech.Recognition;
using System.Diagnostics;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string enUsEngine = string.Empty;

            foreach (RecognizerInfo ri in SpeechRecognitionEngine.InstalledRecognizers())
            {
                if (ri.Culture.Name.Equals("en-US") == true)
                {
                    enUsEngine = ri.Id;
                }

                Console.WriteLine("Culture: " + ri.Culture + ", EngineId: " + ri.Id) ;
            }

            if (string.IsNullOrEmpty(enUsEngine) == true)
            {
                Console.WriteLine("No engine for English");
                return;
            }

            using (SpeechRecognitionEngine recognizer = new SpeechRecognitionEngine(enUsEngine))
            {
                Grammar grammar = new Grammar("computer.xml");

                recognizer.LoadGrammar(grammar);

                recognizer.SetInputToDefaultAudioDevice();
                recognizer.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(recognizer_SpeechRecognized);

                recognizer.RecognizeAsync(RecognizeMode.Multiple);

                while (true)
                {
                    Console.ReadLine();
                }
            }
        }

        static RecognitionState current = RecognitionState.None;

        static void recognizer_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            if (e.Result.Text == "Computer, hibernate yourself" &&
                current == RecognitionState.None)
            {
                current = RecognitionState.Question;

                System.Speech.Synthesis.SpeechSynthesizer tts = new System.Speech.Synthesis.SpeechSynthesizer();
                tts.SetOutputToDefaultAudioDevice();
                tts.Speak("Are you sure?");
                Console.WriteLine("Are you sure?");
                return;
            }

            if (current == RecognitionState.Question)
            {
                current = RecognitionState.None;
                if (e.Result.Text == "Yes")
                {
                    Console.WriteLine("hibernating...");
                    DoHibernation();
                }
                else
                {
                    Console.WriteLine("Canceled.");
                }
            }
        }

        private static void DoHibernation()
        {
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.Arguments = "/h /f";
            psi.FileName = "c:\\windows\\system32\\shutdown.exe";
            Process.Start(psi);
        }
    }

    public enum RecognitionState
    {
        None,
        Question,
    }
}
